import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV),
      'process.browser': JSON.stringify(true),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
        'xlsx': 'xlsx/dist/xlsx.full.min.js',
        'cross-fetch': path.resolve(__dirname, './src/services/fetch-ponyfill.ts'),
        'node-fetch': path.resolve(__dirname, './src/services/fetch-ponyfill.ts'),
        'isomorphic-fetch': path.resolve(__dirname, './src/services/fetch-ponyfill.ts'),
        'p-retry-real': path.resolve(__dirname, './node_modules/p-retry/index.js'),
        'p-retry': path.resolve(__dirname, './src/services/p-retry-wrapper.ts'),
      },
      conditions: ['browser'],
    },
    optimizeDeps: {
      include: ['p-retry', '@google/genai', '@supabase/supabase-js'],
    },
    build: {
      chunkSizeWarningLimit: 2000,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              return 'vendor';
            }
          },
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
