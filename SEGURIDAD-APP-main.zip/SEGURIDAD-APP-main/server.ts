import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { parse } from "csv-parse/sync";
import Database from "better-sqlite3";
import multer from "multer";

const app = express();
const PORT = 3000;
const db = new Database("feedback.db");

// Configure Multer for CSV uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./");
  },
  filename: (req, file, cb) => {
    cb(null, "data.csv"); // Overwrite existing data.csv
  }
});
const upload = multer({ storage });

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id TEXT NOT NULL,
    user_name TEXT,
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS fire_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha TEXT NOT NULL,
    ubicacion TEXT NOT NULL,
    descripcion TEXT NOT NULL,
    estatus TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS security_certs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL,
    vencimiento TEXT NOT NULL,
    entidad TEXT NOT NULL,
    estatus TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS cctv_alarms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha TEXT NOT NULL,
    agencia TEXT NOT NULL,
    descripcion TEXT NOT NULL,
    empresa TEXT NOT NULL,
    cantidad INTEGER NOT NULL,
    precio_unitario REAL NOT NULL,
    total REAL NOT NULL,
    estatus TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Insert sample data if empty
const fireCount = db.prepare("SELECT COUNT(*) as count FROM fire_reports").get() as any;
if (fireCount.count === 0) {
  db.prepare("INSERT INTO fire_reports (fecha, ubicacion, descripcion, estatus) VALUES (?, ?, ?, ?)").run('15/02/2026', 'Agencia Principal', 'Incendio menor en cuarto de servidores, controlado por sistema de extinción.', 'Vigente');
  db.prepare("INSERT INTO fire_reports (fecha, ubicacion, descripcion, estatus) VALUES (?, ?, ?, ?)").run('20/01/2026', 'Agencia San Cristóbal', 'Simulacro de evacuación realizado satisfactoriamente.', 'Vigente');
}

const certCount = db.prepare("SELECT COUNT(*) as count FROM security_certs").get() as any;
if (certCount.count === 0) {
  db.prepare("INSERT INTO security_certs (tipo, vencimiento, entidad, estatus) VALUES (?, ?, ?, ?)").run('Certificado de Seguridad Física', '01/03/2026', 'Alcaldía de San Cristóbal', 'Vigente');
  db.prepare("INSERT INTO security_certs (tipo, vencimiento, entidad, estatus) VALUES (?, ?, ?, ?)").run('Permiso de Bomberos', '15/02/2026', 'Cuerpo de Bomberos', 'Vencido');
  db.prepare("INSERT INTO security_certs (tipo, vencimiento, entidad, estatus) VALUES (?, ?, ?, ?)").run('Certificación de Bóveda', '10/03/2026', 'SUDEBAN', 'Vigente');
}

app.use(express.json());

// API Routes
app.get("/api/cases", (req, res) => {
  try {
    const csvData = fs.readFileSync(path.resolve("data.csv"), "utf-8");
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
      relax_column_count: true
    });
    res.json(records);
  } catch (error) {
    console.error("Error reading CSV:", error);
    res.status(500).json({ error: "Failed to read data" });
  }
});

app.post("/api/upload", upload.single("file"), (req: any, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }
  res.json({ success: true, message: "Datos actualizados correctamente" });
});

app.get("/api/fire-reports", (req, res) => {
  const stmt = db.prepare("SELECT * FROM fire_reports ORDER BY created_at DESC");
  res.json(stmt.all());
});

app.get("/api/security-certs", (req, res) => {
  const stmt = db.prepare("SELECT * FROM security_certs ORDER BY created_at DESC");
  res.json(stmt.all());
});

app.get("/api/cctv-alarms", (req, res) => {
  const stmt = db.prepare("SELECT * FROM cctv_alarms ORDER BY created_at DESC");
  res.json(stmt.all());
});

app.post("/api/import-sheets", async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: "URL is required" });

  try {
    // Convert Google Sheets URL to CSV export URL
    // Format: https://docs.google.com/spreadsheets/d/ID/edit#gid=0 -> https://docs.google.com/spreadsheets/d/ID/export?format=csv
    const sheetIdMatch = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
    if (!sheetIdMatch) return res.status(400).json({ error: "Invalid Google Sheets URL" });
    
    const sheetId = sheetIdMatch[1];
    const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
    
    const response = await fetch(csvUrl);
    if (!response.ok) throw new Error("Failed to fetch Google Sheet");
    
    const csvData = await response.text();
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
      relax_column_count: true
    });

    // Smart ingestion: Use the first few records to determine type or just ingest as "cases" by default
    // For now, we'll assume it's cases if it has ID_Caso, or we can try to be smart.
    // The user wants "IA to decide where it goes".
    
    res.json({ success: true, count: records.length, data: records });
  } catch (error) {
    console.error("Error importing from Google Sheets:", error);
    res.status(500).json({ error: "Failed to import from Google Sheets" });
  }
});

app.post("/api/ingest-smart", async (req, res) => {
  const { content } = req.body;
  if (!content) return res.status(400).json({ error: "No content provided" });

  // This logic would ideally call Gemini, but since we must call GenAI from frontend,
  // we'll return a "pending categorization" or let the frontend handle the classification logic.
  // Actually, the prompt says "processed by the IA and this decides where it goes".
  // I will implement a route that the frontend calls AFTER getting the classification from Gemini.
  res.json({ message: "Endpoint ready for categorized data" });
});

app.post("/api/add-entry", (req, res) => {
  const { type, data } = req.body;
  try {
    if (type === 'case') {
      // For cases, we append to CSV
      const csvLine = `\n"${data.ID_Caso}",${data.FechaReclamo},${data.NumExpediente},${data.NumReclamo},${data.Investigador},${data.AgenciaReporta},${data.TipoHecho},${data.AgenciaOrigen},${data.Vicepresidencia},${data.FechaHecho},"${data.Descripcion}","${data.MontoExpuesto}","${data.MontoAfectado}","${data.MontoRecuperado}",,"${data.Conclusion}","${data.ClienteReceptor}",${data.Estatus}`;
      fs.appendFileSync(path.resolve("data.csv"), csvLine);
    } else if (type === 'fire') {
      const stmt = db.prepare("INSERT INTO fire_reports (fecha, ubicacion, descripcion, estatus) VALUES (?, ?, ?, ?)");
      stmt.run(data.fecha, data.ubicacion, data.descripcion, data.estatus);
    } else if (type === 'cert') {
      const stmt = db.prepare("INSERT INTO security_certs (tipo, vencimiento, entidad, estatus) VALUES (?, ?, ?, ?)");
      stmt.run(data.tipo, data.vencimiento, data.entidad, data.estatus);
    } else if (type === 'cctv') {
      const stmt = db.prepare("INSERT INTO cctv_alarms (fecha, agencia, descripcion, empresa, cantidad, precio_unitario, total, estatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      stmt.run(data.fecha, data.agencia, data.descripcion, data.empresa, data.cantidad, data.precio_unitario, data.total, data.estatus);
    }
    res.json({ success: true });
  } catch (error) {
    console.error("Error adding entry:", error);
    res.status(500).json({ error: "Failed to add entry" });
  }
});

app.post("/api/ingest-bulk", (req, res) => {
  const { type, records } = req.body;
  if (!type || !records || !Array.isArray(records)) {
    return res.status(400).json({ error: "Invalid request body" });
  }

  try {
    if (type === 'case') {
      let csvContent = "";
      for (const data of records) {
        csvContent += `\n"${data.ID_Caso || ''}",${data.FechaReclamo || ''},${data.NumExpediente || ''},${data.NumReclamo || ''},${data.Investigador || ''},${data.AgenciaReporta || ''},${data.TipoHecho || ''},${data.AgenciaOrigen || ''},${data.Vicepresidencia || ''},${data.FechaHecho || ''},"${data.Descripcion || ''}","${data.MontoExpuesto || ''}","${data.MontoAfectado || ''}","${data.MontoRecuperado || ''}",,"${data.Conclusion || ''}","${data.ClienteReceptor || ''}",${data.Estatus || ''}`;
      }
      fs.appendFileSync(path.resolve("data.csv"), csvContent);
    } else if (type === 'fire') {
      const stmt = db.prepare("INSERT INTO fire_reports (fecha, ubicacion, descripcion, estatus) VALUES (?, ?, ?, ?)");
      const insertMany = db.transaction((items) => {
        for (const item of items) stmt.run(item.fecha || '', item.ubicacion || '', item.descripcion || '', item.estatus || 'Vigente');
      });
      insertMany(records);
    } else if (type === 'cert') {
      const stmt = db.prepare("INSERT INTO security_certs (tipo, vencimiento, entidad, estatus) VALUES (?, ?, ?, ?)");
      const insertMany = db.transaction((items) => {
        for (const item of items) stmt.run(item.tipo || '', item.vencimiento || '', item.entidad || '', item.estatus || 'Vigente');
      });
      insertMany(records);
    } else if (type === 'cctv') {
      const stmt = db.prepare("INSERT INTO cctv_alarms (fecha, agencia, descripcion, empresa, cantidad, precio_unitario, total, estatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      const insertMany = db.transaction((items) => {
        for (const item of items) stmt.run(item.fecha || '', item.agencia || '', item.descripcion || '', item.empresa || '', item.cantidad || 0, item.precio_unitario || 0, item.total || 0, item.estatus || 'Pendiente');
      });
      insertMany(records);
    }
    res.json({ success: true, count: records.length });
  } catch (error) {
    console.error("Error in bulk ingest:", error);
    res.status(500).json({ error: "Failed to ingest data" });
  }
});

app.get("/api/feedback/:caseId", (req, res) => {
  const { caseId } = req.params;
  const stmt = db.prepare("SELECT * FROM feedback WHERE case_id = ? ORDER BY created_at DESC");
  const comments = stmt.all(caseId);
  res.json(comments);
});

app.post("/api/feedback", (req, res) => {
  const { case_id, user_name, comment } = req.body;
  if (!case_id || !comment) {
    return res.status(400).json({ error: "Missing required fields" });
  }
  const stmt = db.prepare("INSERT INTO feedback (case_id, user_name, comment) VALUES (?, ?, ?)");
  stmt.run(case_id, user_name || "Anónimo", comment);
  res.json({ success: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve("dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve("dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
